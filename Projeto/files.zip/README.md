# Detecção de Falhas em Rolamentos — Pipeline Completo

## Estrutura

```
rolamentos_tinyml/
├── python/
│   ├── preprocessing.py       # extrai features de janelas de vibração
│   └── train_autoencoder.py   # treina o autoencoder e exporta p/ o ESP32
└── arduino/
    └── esp32_mpu6050_inference/
        └── esp32_mpu6050_inference.ino
```

## Passo a passo

### 1. Coletar dados brutos
Use um sketch simples (não incluso aqui) que leia o MPU6050 e imprima
`timestamp,ax,ay,az` via Serial, redirecionando para CSV (ex: com um script Python
lendo a porta serial, ou o Serial Monitor do Arduino IDE exportando o log).

Colete pelo menos:
- `dados_normal.csv` — motor rodando em condição normal
- `dados_desbalanceado.csv` — motor com massa excêntrica presa ao eixo (opcional, só para avaliação)

### 2. Extrair features (no computador)
```bash
pip install pandas numpy scipy

python preprocessing.py --input dados_normal.csv --label normal --output features_normal.csv
python preprocessing.py --input dados_desbalanceado.csv --label anomalia --output features_anomalia.csv
```

### 3. Treinar o autoencoder e exportar
```bash
pip install tensorflow scikit-learn

python train_autoencoder.py --normal features_normal.csv --anomaly features_anomalia.csv
```
Isso gera três arquivos:
- `bearing_autoencoder.tflite` — modelo quantizado int8
- `normalization.h` — mean/std das features (para normalizar no firmware)
- `threshold.h` — limiar de erro de reconstrução

### 4. Converter o .tflite para array C
```bash
xxd -i bearing_autoencoder.tflite > model.h
```
Abra o `model.h` gerado e renomeie a variável do array para
`bearing_autoencoder_tflite` (ou ajuste o nome usado no `.ino`, que precisa bater).

### 5. Montar o firmware
Copie `model.h`, `normalization.h` e `threshold.h` para dentro da pasta
`arduino/esp32_mpu6050_inference/` (mesma pasta do `.ino`), abra no Arduino IDE,
selecione a placa ESP32 e faça o upload.

### 6. Monitorar
Abra o Serial Monitor (115200 baud) e observe o erro de reconstrução por janela,
comparado ao threshold. O LED/buzzer acende quando uma anomalia é detectada.

## Observações importantes

- **A ordem das features deve ser idêntica** entre `preprocessing.py` (Python) e
  `flatten_features()` (C/firmware). Se você adicionar ou remover uma feature em um lado,
  replique no outro.
- Se o Arduino IDE reclamar de `kTensorArenaSize` insuficiente, aumente o valor em
  `esp32_mpu6050_inference.ino` (ex: de 20KB para 30-40KB) — o ESP32 costuma ter RAM de sobra
  para isso comparado a microcontroladores menores.
- A taxa de amostragem real via I2C pode ser menor que os 100Hz nominais dependendo do
  overhead de leitura do MPU6050 — meça isso na Semana 1 do cronograma e ajuste
  `SAMPLE_RATE_HZ` nos dois lados (Python e firmware) se necessário.
