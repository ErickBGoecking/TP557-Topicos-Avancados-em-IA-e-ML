"""
preprocessing.py
-----------------
Pré-processamento de sinais de vibração coletados do MPU6050 (ESP32).

Fluxo:
1. Lê um CSV bruto com colunas: timestamp, ax, ay, az (aceleração nos 3 eixos)
2. Divide o sinal em janelas (com sobreposição opcional)
3. Extrai features no domínio do tempo e da frequência de cada janela
4. Salva um dataset de features (uma linha = uma janela) pronto para treino

Uso típico:
    python preprocessing.py --input dados_normal.csv --label normal --output features_normal.csv
    python preprocessing.py --input dados_desbalanceado.csv --label anomalia --output features_anomalia.csv
"""

import argparse
import numpy as np
import pandas as pd
from scipy.stats import kurtosis, skew
from scipy.fft import rfft, rfftfreq

# ---------------------------------------------------------------------------
# Parâmetros de janelamento — devem ser IGUAIS aos usados depois no firmware
# ---------------------------------------------------------------------------
SAMPLE_RATE_HZ = 100        # taxa de amostragem alvo (ajuste conforme o que o MPU6050/I2C sustenta)
WINDOW_SIZE = 200           # amostras por janela -> 200 / 100Hz = 2 segundos por janela
WINDOW_OVERLAP = 0.5        # 50% de sobreposição entre janelas consecutivas


def window_signal(signal: np.ndarray, window_size: int, overlap: float):
    """Divide um array 1D em janelas com sobreposição."""
    step = int(window_size * (1 - overlap))
    windows = []
    for start in range(0, len(signal) - window_size + 1, step):
        windows.append(signal[start:start + window_size])
    return windows


def time_domain_features(window: np.ndarray) -> dict:
    """Features clássicas de vibração no domínio do tempo."""
    rms = np.sqrt(np.mean(window ** 2))
    peak = np.max(np.abs(window))
    peak_to_peak = np.max(window) - np.min(window)
    crest_factor = peak / rms if rms > 0 else 0.0
    return {
        "mean": np.mean(window),
        "std": np.std(window),
        "rms": rms,
        "peak": peak,
        "peak_to_peak": peak_to_peak,
        "crest_factor": crest_factor,
        "kurtosis": kurtosis(window),
        "skewness": skew(window),
    }


def freq_domain_features(window: np.ndarray, fs: int) -> dict:
    """Features no domínio da frequência via FFT (só magnitude, sinal real)."""
    n = len(window)
    fft_vals = np.abs(rfft(window - np.mean(window)))  # remove componente DC
    freqs = rfftfreq(n, d=1.0 / fs)

    # energia espectral total
    spectral_energy = np.sum(fft_vals ** 2)

    # frequência dominante (pico do espectro)
    dominant_freq = freqs[np.argmax(fft_vals)] if len(fft_vals) > 0 else 0.0

    # centróide espectral (indica "onde está concentrada" a energia)
    spectral_centroid = (
        np.sum(freqs * fft_vals) / np.sum(fft_vals) if np.sum(fft_vals) > 0 else 0.0
    )

    return {
        "spectral_energy": spectral_energy,
        "dominant_freq": dominant_freq,
        "spectral_centroid": spectral_centroid,
    }


def extract_features_from_axis(window: np.ndarray, fs: int, axis_name: str) -> dict:
    feats = {}
    feats.update({f"{axis_name}_{k}": v for k, v in time_domain_features(window).items()})
    feats.update({f"{axis_name}_{k}": v for k, v in freq_domain_features(window, fs).items()})
    return feats


def process_csv(input_path: str, label: str, fs: int, window_size: int, overlap: float) -> pd.DataFrame:
    df = pd.read_csv(input_path)
    required_cols = {"ax", "ay", "az"}
    if not required_cols.issubset(df.columns):
        raise ValueError(f"CSV precisa ter colunas {required_cols}, encontrado: {list(df.columns)}")

    windows_ax = window_signal(df["ax"].values, window_size, overlap)
    windows_ay = window_signal(df["ay"].values, window_size, overlap)
    windows_az = window_signal(df["az"].values, window_size, overlap)

    rows = []
    for wx, wy, wz in zip(windows_ax, windows_ay, windows_az):
        row = {}
        row.update(extract_features_from_axis(wx, fs, "ax"))
        row.update(extract_features_from_axis(wy, fs, "ay"))
        row.update(extract_features_from_axis(wz, fs, "az"))
        row["label"] = label
        rows.append(row)

    return pd.DataFrame(rows)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Extrai features de vibração de um CSV bruto do MPU6050.")
    parser.add_argument("--input", required=True, help="CSV bruto com colunas timestamp, ax, ay, az")
    parser.add_argument("--label", required=True, help="Rótulo da classe (ex: normal, desbalanceado)")
    parser.add_argument("--output", required=True, help="CSV de saída com as features extraídas")
    parser.add_argument("--fs", type=int, default=SAMPLE_RATE_HZ)
    parser.add_argument("--window_size", type=int, default=WINDOW_SIZE)
    parser.add_argument("--overlap", type=float, default=WINDOW_OVERLAP)
    args = parser.parse_args()

    features_df = process_csv(args.input, args.label, args.fs, args.window_size, args.overlap)
    features_df.to_csv(args.output, index=False)
    print(f"[OK] {len(features_df)} janelas processadas -> {args.output}")
    print(f"Colunas de features geradas ({len(features_df.columns) - 1}): {list(features_df.columns[:-1])}")
