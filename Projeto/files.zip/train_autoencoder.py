"""
train_autoencoder.py
---------------------
Treina um autoencoder para detecção de anomalias em rolamentos, usando SOMENTE
janelas de vibração "normais" (não precisa de dados de todas as falhas possíveis).

Fluxo:
1. Carrega o CSV de features "normal" (gerado pelo preprocessing.py)
2. Normaliza as features (guarda mean/std para reproduzir no firmware, em C)
3. Treina um autoencoder denso (encoder-decoder) só com dados normais
4. Define um threshold de erro de reconstrução (normal vs. anomalia)
5. Avalia (opcionalmente) contra um CSV de features "anomalia", se existir
6. Converte o modelo para TensorFlow Lite com quantização int8
7. Gera um arquivo model.h (array C) pronto para colar no firmware do ESP32

Uso típico:
    python train_autoencoder.py --normal features_normal.csv --anomaly features_anomalia.csv
"""

import argparse
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from sklearn.model_selection import train_test_split


def load_features(csv_path: str):
    df = pd.read_csv(csv_path)
    feature_cols = [c for c in df.columns if c != "label"]
    X = df[feature_cols].values.astype(np.float32)
    return X, feature_cols


def build_autoencoder(input_dim: int) -> keras.Model:
    """Autoencoder pequeno o suficiente para caber em um microcontrolador."""
    inputs = keras.Input(shape=(input_dim,))
    # Encoder
    x = keras.layers.Dense(16, activation="relu")(inputs)
    x = keras.layers.Dense(8, activation="relu")(x)
    bottleneck = keras.layers.Dense(4, activation="relu", name="bottleneck")(x)
    # Decoder
    x = keras.layers.Dense(8, activation="relu")(bottleneck)
    x = keras.layers.Dense(16, activation="relu")(x)
    outputs = keras.layers.Dense(input_dim, activation="linear")(x)

    model = keras.Model(inputs, outputs, name="bearing_autoencoder")
    model.compile(optimizer="adam", loss="mse")
    return model


def reconstruction_error(model: keras.Model, X: np.ndarray) -> np.ndarray:
    X_pred = model.predict(X, verbose=0)
    return np.mean(np.square(X - X_pred), axis=1)


def representative_dataset_gen(X_train: np.ndarray):
    """Gerador exigido pelo TFLite Converter para calibrar a quantização int8."""
    def gen():
        for i in range(min(200, len(X_train))):
            yield [X_train[i:i + 1].astype(np.float32)]
    return gen


def convert_to_tflite(model: keras.Model, X_train: np.ndarray, output_path: str):
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.representative_dataset = representative_dataset_gen(X_train)
    # Quantização full int8 (menor footprint, ideal para ESP32)
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type = tf.int8
    converter.inference_output_type = tf.int8

    tflite_model = converter.convert()
    with open(output_path, "wb") as f:
        f.write(tflite_model)
    print(f"[OK] Modelo TFLite salvo em {output_path} ({len(tflite_model)} bytes)")
    return tflite_model


def export_normalization_header(mean: np.ndarray, std: np.ndarray, feature_names, path: str):
    """Exporta mean/std como arrays C, já que não há sklearn no ESP32."""
    with open(path, "w") as f:
        f.write("// Gerado automaticamente por train_autoencoder.py\n")
        f.write("// Ordem das features:\n")
        for i, name in enumerate(feature_names):
            f.write(f"// [{i}] {name}\n")
        f.write(f"\n#define NUM_FEATURES {len(feature_names)}\n\n")
        f.write("const float FEATURE_MEAN[NUM_FEATURES] = {" +
                 ", ".join(f"{v:.6f}f" for v in mean) + "};\n\n")
        f.write("const float FEATURE_STD[NUM_FEATURES] = {" +
                 ", ".join(f"{v:.6f}f" for v in std) + "};\n")
    print(f"[OK] Normalização exportada em {path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Treina o autoencoder de detecção de anomalia.")
    parser.add_argument("--normal", required=True, help="CSV de features de vibração normal")
    parser.add_argument("--anomaly", required=False, help="CSV de features com falha, só para avaliação")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--threshold_percentile", type=float, default=95,
                         help="Percentil do erro de reconstrução (dados normais) usado como limiar")
    args = parser.parse_args()

    # 1. Carregar dados normais
    X, feature_names = load_features(args.normal)
    X_train, X_val = train_test_split(X, test_size=0.2, random_state=42)

    # 2. Normalizar (guardando mean/std para uso no firmware)
    mean = X_train.mean(axis=0)
    std = X_train.std(axis=0) + 1e-8  # evita divisão por zero
    X_train_norm = (X_train - mean) / std
    X_val_norm = (X_val - mean) / std

    # 3. Treinar autoencoder
    model = build_autoencoder(input_dim=X.shape[1])
    early_stop = keras.callbacks.EarlyStopping(monitor="val_loss", patience=10, restore_best_weights=True)
    model.fit(
        X_train_norm, X_train_norm,
        validation_data=(X_val_norm, X_val_norm),
        epochs=args.epochs,
        batch_size=16,
        callbacks=[early_stop],
        verbose=2,
    )

    # 4. Definir threshold com base no erro de reconstrução dos dados normais de validação
    val_errors = reconstruction_error(model, X_val_norm)
    threshold = float(np.percentile(val_errors, args.threshold_percentile))
    print(f"\n[THRESHOLD] Erro de reconstrução (percentil {args.threshold_percentile}): {threshold:.6f}")

    # 5. Avaliação opcional contra dados de anomalia
    if args.anomaly:
        X_anom, _ = load_features(args.anomaly)
        X_anom_norm = (X_anom - mean) / std
        anom_errors = reconstruction_error(model, X_anom_norm)

        detected = np.mean(anom_errors > threshold) * 100
        false_positives = np.mean(val_errors > threshold) * 100
        print(f"[AVALIAÇÃO] Anomalias corretamente detectadas: {detected:.1f}%")
        print(f"[AVALIAÇÃO] Falsos positivos em dados normais: {false_positives:.1f}%")

    # 6. Exportar modelo para TFLite (int8)
    convert_to_tflite(model, X_train_norm, "bearing_autoencoder.tflite")

    # 7. Exportar mean/std e threshold para o firmware
    export_normalization_header(mean, std, feature_names, "normalization.h")
    with open("threshold.h", "w") as f:
        f.write(f"#define ANOMALY_THRESHOLD {threshold:.6f}f\n")
    print("[OK] threshold.h gerado")

    print("\nPróximo passo: rode 'xxd -i bearing_autoencoder.tflite > model.h' "
          "e cole o conteúdo no firmware do ESP32.")
