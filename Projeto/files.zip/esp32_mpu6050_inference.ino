/*
  esp32_mpu6050_inference.ino
  ----------------------------
  Detecção de falhas em rolamentos com autoencoder rodando em TFLite Micro.

  Fluxo no dispositivo:
  1. Lê janelas de aceleração (ax, ay, az) do MPU6050 via I2C
  2. Extrai as MESMAS features calculadas em preprocessing.py (tempo + frequência)
  3. Normaliza usando mean/std exportados do treino (normalization.h)
  4. Roda inferência do autoencoder (TFLite Micro)
  5. Calcula erro de reconstrução e compara com o threshold (threshold.h)
  6. Se erro > threshold -> aciona LED/buzzer (anomalia detectada)

  Bibliotecas necessárias (Arduino IDE > Gerenciador de Bibliotecas):
  - Adafruit MPU6050
  - Adafruit Unified Sensor
  - arduinoFFT
  - Arduino_TensorFlowLite (ou TFLite Micro ESP-IDF component, conforme sua toolchain)

  Arquivos que devem estar na mesma pasta do sketch:
  - model.h            (gerado com: xxd -i bearing_autoencoder.tflite > model.h)
  - normalization.h    (gerado por train_autoencoder.py)
  - threshold.h         (gerado por train_autoencoder.py)
*/

#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <arduinoFFT.h>

#include "model.h"
#include "normalization.h"
#include "threshold.h"

#include <TensorFlowLite_ESP32.h>
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_error_reporter.h"
#include "tensorflow/lite/schema/schema_generated.h"

// ---------------------------------------------------------------------------
// Configurações — DEVEM bater com o que foi usado no preprocessing.py
// ---------------------------------------------------------------------------
#define SAMPLE_RATE_HZ 100
#define WINDOW_SIZE 200          // 200 amostras / 100Hz = 2s por janela
#define BUZZER_PIN 25
#define LED_PIN 2                // LED onboard da maioria das placas ESP32 DevKit

Adafruit_MPU6050 mpu;

double vReal_x[WINDOW_SIZE], vImag_x[WINDOW_SIZE];
double vReal_y[WINDOW_SIZE], vImag_y[WINDOW_SIZE];
double vReal_z[WINDOW_SIZE], vImag_z[WINDOW_SIZE];

float raw_ax[WINDOW_SIZE], raw_ay[WINDOW_SIZE], raw_az[WINDOW_SIZE];

// ---------------------------------------------------------------------------
// TensorFlow Lite Micro — setup
// ---------------------------------------------------------------------------
namespace {
tflite::MicroErrorReporter micro_error_reporter;
tflite::ErrorReporter* error_reporter = &micro_error_reporter;
const tflite::Model* model = nullptr;
tflite::MicroInterpreter* interpreter = nullptr;
TfLiteTensor* input = nullptr;
TfLiteTensor* output = nullptr;

// Arena de memória para o interpretador — ajuste se der erro de "arena too small"
constexpr int kTensorArenaSize = 20 * 1024;
uint8_t tensor_arena[kTensorArenaSize];
}  // namespace

void setup_tflite() {
  model = tflite::GetModel(bearing_autoencoder_tflite);  // nome gerado pelo xxd a partir do .tflite
  if (model->version() != TFLITE_SCHEMA_VERSION) {
    error_reporter->Report("Versao do modelo incompativel com o schema do TFLite Micro");
    while (1) delay(1000);
  }

  static tflite::AllOpsResolver resolver;
  static tflite::MicroInterpreter static_interpreter(
      model, resolver, tensor_arena, kTensorArenaSize, error_reporter);
  interpreter = &static_interpreter;

  if (interpreter->AllocateTensors() != kTfLiteOk) {
    error_reporter->Report("Falha ao alocar tensores");
    while (1) delay(1000);
  }

  input = interpreter->input(0);
  output = interpreter->output(0);
}

// ---------------------------------------------------------------------------
// Extração de features (mesma lógica de preprocessing.py, em C)
// ---------------------------------------------------------------------------
struct AxisFeatures {
  float mean, std, rms, peak, peak_to_peak, crest_factor, kurtosis, skewness;
  float spectral_energy, dominant_freq, spectral_centroid;
};

AxisFeatures extract_axis_features(float* raw, double* vReal, double* vImag, int n, int fs) {
  AxisFeatures f;

  // --- domínio do tempo ---
  double sum = 0, sum_sq = 0;
  float peak = 0, vmin = raw[0], vmax = raw[0];
  for (int i = 0; i < n; i++) {
    sum += raw[i];
    if (raw[i] > vmax) vmax = raw[i];
    if (raw[i] < vmin) vmin = raw[i];
    if (fabs(raw[i]) > peak) peak = fabs(raw[i]);
  }
  f.mean = sum / n;
  for (int i = 0; i < n; i++) sum_sq += pow(raw[i] - f.mean, 2);
  f.std = sqrt(sum_sq / n);
  f.rms = 0;
  for (int i = 0; i < n; i++) f.rms += raw[i] * raw[i];
  f.rms = sqrt(f.rms / n);
  f.peak = peak;
  f.peak_to_peak = vmax - vmin;
  f.crest_factor = (f.rms > 0) ? (f.peak / f.rms) : 0;

  double m3 = 0, m4 = 0;
  for (int i = 0; i < n; i++) {
    double d = raw[i] - f.mean;
    m3 += pow(d, 3);
    m4 += pow(d, 4);
  }
  m3 /= n; m4 /= n;
  double var = f.std * f.std;
  f.skewness = (var > 0) ? m3 / pow(var, 1.5) : 0;
  f.kurtosis = (var > 0) ? (m4 / (var * var)) - 3.0 : 0;  // excess kurtosis, igual ao scipy

  // --- domínio da frequência (FFT via arduinoFFT) ---
  for (int i = 0; i < n; i++) {
    vReal[i] = raw[i] - f.mean;  // remove DC
    vImag[i] = 0;
  }
  ArduinoFFT<double> FFT = ArduinoFFT<double>(vReal, vImag, n, fs);
  FFT.windowing(FFT_WIN_TYP_HAMMING, FFT_FORWARD);
  FFT.compute(FFT_FORWARD);
  FFT.complexToMagnitude();

  double energy = 0, weighted_sum = 0, mag_sum = 0, max_mag = 0, dom_freq = 0;
  for (int i = 0; i < n / 2; i++) {
    double freq = (i * 1.0 * fs) / n;
    energy += vReal[i] * vReal[i];
    weighted_sum += freq * vReal[i];
    mag_sum += vReal[i];
    if (vReal[i] > max_mag) { max_mag = vReal[i]; dom_freq = freq; }
  }
  f.spectral_energy = energy;
  f.dominant_freq = dom_freq;
  f.spectral_centroid = (mag_sum > 0) ? (weighted_sum / mag_sum) : 0;

  return f;
}

// Achata as features das 3 features na MESMA ordem usada no treino em Python
// (ax_* depois ay_* depois az_*, cada bloco: mean, std, rms, peak, peak_to_peak,
//  crest_factor, kurtosis, skewness, spectral_energy, dominant_freq, spectral_centroid)
void flatten_features(AxisFeatures& fx, AxisFeatures& fy, AxisFeatures& fz, float* out) {
  AxisFeatures axes[3] = {fx, fy, fz};
  int idx = 0;
  for (int a = 0; a < 3; a++) {
    out[idx++] = axes[a].mean;
    out[idx++] = axes[a].std;
    out[idx++] = axes[a].rms;
    out[idx++] = axes[a].peak;
    out[idx++] = axes[a].peak_to_peak;
    out[idx++] = axes[a].crest_factor;
    out[idx++] = axes[a].kurtosis;
    out[idx++] = axes[a].skewness;
    out[idx++] = axes[a].spectral_energy;
    out[idx++] = axes[a].dominant_freq;
    out[idx++] = axes[a].spectral_centroid;
  }
}

// ---------------------------------------------------------------------------
// Setup / Loop
// ---------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  Wire.begin();  // SDA = GPIO21, SCL = GPIO22 (padrão do ESP32)
  if (!mpu.begin()) {
    Serial.println("Falha ao encontrar o MPU6050. Verifique as ligacoes I2C.");
    while (1) delay(1000);
  }
  mpu.setAccelerometerRange(MPU6050_RANGE_4_G);
  mpu.setFilterBandwidth(MPU6050_BAND_44_HZ);
  Serial.println("MPU6050 inicializado.");

  setup_tflite();
  Serial.println("Modelo TFLite Micro carregado. Iniciando monitoramento...");
}

void loop() {
  // 1. Coleta de uma janela de WINDOW_SIZE amostras
  unsigned long sample_interval_us = 1000000UL / SAMPLE_RATE_HZ;
  for (int i = 0; i < WINDOW_SIZE; i++) {
    unsigned long t0 = micros();
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    raw_ax[i] = a.acceleration.x;
    raw_ay[i] = a.acceleration.y;
    raw_az[i] = a.acceleration.z;
    while (micros() - t0 < sample_interval_us) { /* aguarda para manter taxa constante */ }
  }

  // 2. Extração de features
  AxisFeatures fx = extract_axis_features(raw_ax, vReal_x, vImag_x, WINDOW_SIZE, SAMPLE_RATE_HZ);
  AxisFeatures fy = extract_axis_features(raw_ay, vReal_y, vImag_y, WINDOW_SIZE, SAMPLE_RATE_HZ);
  AxisFeatures fz = extract_axis_features(raw_az, vReal_z, vImag_z, WINDOW_SIZE, SAMPLE_RATE_HZ);

  float features[NUM_FEATURES];
  flatten_features(fx, fy, fz, features);

  // 3. Normalização (usa mean/std vindos do treino) + quantização int8 para o tensor de entrada
  float scale = input->params.scale;
  int zero_point = input->params.zero_point;
  for (int i = 0; i < NUM_FEATURES; i++) {
    float norm = (features[i] - FEATURE_MEAN[i]) / FEATURE_STD[i];
    int8_t quantized = (int8_t)(norm / scale + zero_point);
    input->data.int8[i] = quantized;
  }

  // 4. Inferência
  if (interpreter->Invoke() != kTfLiteOk) {
    Serial.println("Erro na inferencia");
    return;
  }

  // 5. Erro de reconstrução (MSE entre entrada normalizada e saída do autoencoder)
  float out_scale = output->params.scale;
  int out_zero_point = output->params.zero_point;
  float mse = 0;
  for (int i = 0; i < NUM_FEATURES; i++) {
    float in_norm = (features[i] - FEATURE_MEAN[i]) / FEATURE_STD[i];
    float out_val = (output->data.int8[i] - out_zero_point) * out_scale;
    mse += pow(in_norm - out_val, 2);
  }
  mse /= NUM_FEATURES;

  // 6. Decisão
  bool anomaly = mse > ANOMALY_THRESHOLD;
  Serial.print("Erro de reconstrucao: ");
  Serial.print(mse, 6);
  Serial.print(" | Threshold: ");
  Serial.print(ANOMALY_THRESHOLD, 6);
  Serial.println(anomaly ? "  -> ANOMALIA DETECTADA" : "  -> normal");

  digitalWrite(LED_PIN, anomaly ? HIGH : LOW);
  digitalWrite(BUZZER_PIN, anomaly ? HIGH : LOW);

  delay(200);  // pequeno intervalo antes da próxima janela
}
